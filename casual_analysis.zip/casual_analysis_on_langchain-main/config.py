OPEN_API_KEY = ""
serpapi = ''
pinecone_api = ''
pinecone_env = ''
pinecone_index_name = ''
