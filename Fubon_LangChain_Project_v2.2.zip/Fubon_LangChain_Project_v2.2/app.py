from flask import Flask, request, render_template, make_response, jsonify
from flask_cors import CORS, cross_origin
from getCustomerDataset import  getCsvDataset
import time
import os
import tempfile
import pandas as pd

from Langchain_Agent import Agent_Executor, SummaryFunc, RetrievalQA, llm, reload


# Global Variables: 儲存資料來渲染表格
Ai_response = ""

# Flask App
app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False
CORS(app)

# Backend API
@app.route('/get_answer', methods=['POST', 'OPTIONS'])
@cross_origin()
def process_input():

    global Ai_response

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']
    try:
        SummaryFunc.Input_Question = user_input
        Ai_response = Agent_Executor.invoke({"input": user_input})['output']
        
        if not isinstance(Ai_response, str):
            if (Ai_response is None or len(Ai_response) == 0):
                result = '資料不存在'
            # result = Ai_response.to_string(index=False)
            result = "完成資料搜尋"
            return make_response(jsonify({'response': result, 'data': Ai_response.to_json(orient='records')}), 200, header)
        
        result = Ai_response

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\nThe error message is here: {e}')
    
    return make_response(jsonify({'response': result}), 200, header)

@app.route("/table")
def table():
    id = request.args.get('id')
    # return render_template('table.html', dataset=Ai_response.to_dict(orient='records'))
    try:
        return render_template('table.html', dataset=SummaryFunc.datasets[int(id)].to_dict(orient='records'))
    except:
        return render_template('nodata.html')


@app.route('/get_analysis', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_analysis():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']

    try:
        result = SummaryFunc.query(user_input)

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\nThe error message is here: {e}')

    return make_response(jsonify({'response': result}), 200, header)



@app.route('/upload_doc', methods=['POST'])
@cross_origin()
def upload_documents():
    responses = []
    print(f'\nfile objects that I receive in this upload:{request.files}')
    if 'file' not in request.files:
        return jsonify({'message': 'No file part in the request.'}), 400

    files = request.files.getlist('file')  # Get the list of files

    for file in files:
        print('\nthis file:', file)
        if file.filename == '':
            responses.append({'message': '''There's a bad file.''', 'code': 400})
        
        try:
            # Save the file to a temporary location with original extension
            temp_name = ''
            extension = os.path.splitext(file.filename)[-1].lower()
            if extension == ".csv":
                directory = "./database/File/"
                with open(directory+file.filename, 'w') as local_file:
                    file.save(local_file.name)
                    print("Saved file:", file.filename)

                with open(directory+"tables.txt", 'w') as file:
                    for csv in os.listdir(directory):
                        csv_name, csv_extentsion = csv.split('.')
                        if  csv_extentsion == "csv":
                            file.writelines(csv_name+" | "+", ".join(column for column in list(pd.read_csv(directory+csv, nrows=0).columns))+"\n")
                
                Agent_Executor = reload()

            else:
                with tempfile.NamedTemporaryFile(delete=False, suffix=extension) as temp_file:
                    temp_name = temp_file.name
                    file.save(temp_name)
                    print("Temporary file path:", temp_name)
                RetrievalQA.process_and_store_documents([temp_name])
                responses.append({
                    'message': f'File uploaded and processed successfully to Temporary space {temp_file.name}', 'code': 200
                })
        except Exception as e:
            app.logger.debug('Debug message')
            print(str(e))
        finally:
            # Delete the temporary file
            if temp_name:
                os.remove(temp_name)
    
    responses.append('end message:file upload successfully finished')
    return jsonify({'responses': responses}), 200


@app.route('/get_qa', methods=['POST', 'OPTIONS'])
@cross_origin()
def get_qa():
    
    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }
    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']

    try:
        result = RetrievalQA.invoke(user_input)

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\nThe error message is here: {e}')

    return make_response(jsonify({'response': result}), 200, header)

@app.after_request
def after_request(response):
    response.access_control_allow_origin = "*"
    return response

if __name__ == "__main__":
    app.run(debug=True, port=5001)










