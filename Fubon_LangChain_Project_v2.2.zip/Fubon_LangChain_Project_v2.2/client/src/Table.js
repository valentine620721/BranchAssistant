import React, { useState, useEffect } from 'react';
import axios from 'axios'; // 如果您選擇使用 Axios 來處理 HTTP 請求

import './Table.css'

function HtmlRenderer() {
  const [htmlData, setHtmlData] = useState('');
  const [id, setID] = useState(0);

  useEffect(() => {
    // 在 useEffect 中發送 HTTP 請求並獲取後端傳來的 HTML 資料
    async function fetchHtmlData() {
      try {
        const response = await axios.get( `http://localhost:5001/table?id=${id}`);
        setHtmlData(response.data); // 將獲取到的 HTML 資料存儲到狀態中
      } catch (error) {
        console.error('Error fetching HTML data:', error);
      }
    }

    fetchHtmlData(); // 調用函數以觸發 HTTP 請求
  }, [id]);
  
  let rows = []
  for (let i=0; i < 3; i++) {
    rows.push(<button onClick={() => setID(i)}>{i+1}</button>);
  }

  return (
    <>
      {rows}
      <div dangerouslySetInnerHTML={{ __html: htmlData }} />
    </>
  );
}

export default HtmlRenderer;