from langchain.pydantic_v1 import BaseModel, Field
from langchain.tools import BaseTool, StructuredTool, tool

from getCustomerDataset import  getCsvDataset

from getSummary import getSummary


SummaryFunc = getSummary()

# === Calculator ===
class CalculatorInput(BaseModel):
    a: int = Field(description="first number")
    b: int = Field(description="second number")


def multiply(a: int, b: int) -> int:
    """Multiply two numbers."""
    return a * b


calculator = StructuredTool.from_function(
    func=multiply,
    name="calculator",
    description="multiply numbers",
    args_schema=CalculatorInput,
    return_direct=True,
    # coroutine= ... <- you can specify an async method if desired as well
)

# === Get Word Length ===
class WordLengthInput(BaseModel):
    word: str = Field(description="a word or a string")


def get_word_length(word: str) -> int:
    return len(word)

getWordLength = StructuredTool.from_function(
    func=get_word_length,
    name="getWordLength",
    description="Returns the length of a word",
    args_schema=WordLengthInput,
    return_direct=True,
    # coroutine= ... <- you can specify an async method if desired as well
)

# === searchFromFile ===
class SearchInput(BaseModel):
    sqlCommand: str = Field(description='''
    Expected a SQL Command with field names of dataset: Transaction_ID,Employee_ID,Employee_Name,Transaction_Date,Product_Name,Transaction_Amount,Customer_ID,Customer_Name.
    
    Noticed that:
    1. Give the date field data like 20240101, not '2024-01-01' .
    2. If user say that don't want repeated data, use SELECT DISTINCT ...
    3. If user wants separate aggregated data like SUM(data) within a group, use SELECT XXX, ...  GROUP BY XXX, ...; , if not, don't use GROUP BY.
    4. Make SQL Command as short as possible.
    
    Examples:
    1.  Prompt: 請給我每個員工的總業績，需包含姓名欄位
        Answer: SELECT Employee_ID, Employee_Name, SUM(Transaction_Amount) FROM ... GROUP BY Employee_ID, Employee_Name
    
    Check the format must be like SELECT ... FROM ... WHERE ...;, DOUBLE CHECK the notices and problems.
    ''')
    #5. If user request information about something, always use SELECT Column name FROM ...

    # Used for search. Word integrity and correctness is important. MUST double check. All words included in one string
    # Expected a SQL Command, ex. SELECT * FROM Table WHERE ..., noticed that input may include name, date, amount...

    # "Expected a Dictionary format data for SQL search, extract as much data as you can,\
    #  ex. \
    #  human prompt: 搜尋客戶ID是F1234 2024/01/01前且金額大於100的資料 \
    #  input:\
    #  '''{{ 'word': {{\
    #     'customer id': 'F1234',\
    #     'amount': '>100',\
    #     'end_data': '2024/01/01' \
    #     ...\
    #     'human prompt': '搜尋客戶ID是F1234 2024/01/01前且金額大於100的資料'\
    #  }} }}'''\
    #  "

def search_from_file(sqlCommand: str) -> str:
    # 加入 API， return 查詢結果

    return SummaryFunc.store_dataset(getCsvDataset.dataset_query_sql("./dataset/客戶業績資料表.csv", llm, sqlCommand))

searchFromFile = StructuredTool.from_function(
    func=search_from_file,
    name="search from file",
    description="Search for the desired data from 客戶業績資料 using SQL command and returns the search results.",
    args_schema=SearchInput,
    return_direct=True,
    # coroutine= ... <- you can specify an async method if desired as well
)

# === searchFromFile2 ===
class SearchInput2(BaseModel):
    sqlCommand: str = Field(description='''
    Expected a SQL Command with field names of dataset: 起始日期, 結束日期, 新聞標題, 新聞數量.

    Noticed that:
    1. Give the date field data like 20240101, not '2024-01-01' 
    2. If user say that don't want repeated data, use SELECT DISTINCT ...
    3. If user wants separate aggregated data like SUM(data) within a group, use SELECT XXX, ...  GROUP BY XXX, ...; , if not, don't use GROUP BY.
    4. Make SQL Command as short as possible.

    Example:
    1.  Prompt: 我想搜尋在2023/09/22後 新聞數量最多的五個新聞
        Answer: SELECT * FROM ... WHERE 起始日期 > 20230922 ORDER BY 新聞數量 DESC LIMIT 5

    Check the format must be like SELECT ... FROM ... WHERE ...;, DOUBLE CHECK the notices and problems.
    ''')

def search_from_news(sqlCommand: str) -> str:

    return SummaryFunc.store_dataset(getCsvDataset.dataset_query_sql("./dataset/臺北市新聞統計資料.csv", llm, sqlCommand))

searchFromNews = StructuredTool.from_function(
    func=search_from_news,
    name="search from News",
    description="Search for the desired data from 臺北市新聞統計資料 using SQL command and returns the search results.",
    args_schema=SearchInput2,
    return_direct=True,
    # coroutine= ... <- you can specify an async method if desired as well
)

class SummarySchema(BaseModel):
    input: str = Field(description='''
            input as same as user input.
    ''')

def summaryDataset(nothing: str) -> str:
    # return SummaryFunc.get_dataset()
    return SummaryFunc.summary(llm)

summaryFromData = StructuredTool.from_function(
    func=summaryDataset,
    name="dataset summary",
    description="summarize the datasets. Just Input 'NULL'",
    return_direct=True,
    # coroutine= ... <- you can specify an async method if desired as well
)

# === All Tools ===
tools = [calculator, getWordLength, searchFromFile, searchFromNews, summaryFromData]


# === LLM ===
from langchain_community.llms import Ollama

# llm = Ollama(model = "llama3", temperature = 0, num_predict=320)
llm = Ollama(model = "mistral", temperature = 0.3)

# === Memory ===
# from langchain.memory import ConversationBufferWindowMemory
# from langchain.agents import load_tools

# memory = ConversationBufferWindowMemory(
#     memory_key="chat_history", k=2, return_messages=True, output_key="output"
# )# , output_key="output"


# === Prompt Template ===
system = '''Respond to the human as helpfully and accurately as possible. You have access to the following tools:

{tools}

Use a json blob to specify a tool by providing an action key (tool name) and an action_input key (tool input).

Valid "action" values: "Final Answer" or {tool_names}

Provide only ONE action per $JSON_BLOB, as shown:
Action (Json format):
```
{{
  "action": $TOOL_NAME,
  "action_input": $INPUT
}}
```

Follow this format:

Question: input question to answer
Thought: consider what input do action required, must follow the description that action provided
Action (Json format):
```
$JSON_BLOB
```
Observation: action result
... (repeat Thought/Action/Observation 3 times)
Thought: I know what to respond
Action (Json format):
```
{{
  "action": "Final Answer",
  "action_input": "Final response to human"
}}
```

Begin! 
Reminder to ALWAYS respond with a valid json blob of a single action. 
Use tools if necessary. Respond directly if appropriate. 
Format is Action: ```$JSON_BLOB```then Observation
'''

human = '''{input}

{agent_scratchpad}

(reminder to respond in a JSON blob no matter what)'''

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import AIMessage


prompt = ChatPromptTemplate.from_messages(
    [
        ("system", system),
        # MessagesPlaceholder("chat_history", optional=True),
        ("human", human),
    ]
)

# === Agent ===
from langchain.agents import create_structured_chat_agent

my_agent = create_structured_chat_agent(llm, tools, prompt)


# === Agent Executor ===
from langchain.agents import AgentExecutor

Agent_Executor = AgentExecutor(agent = my_agent, verbose=True, tools = tools, max_iterations=3) #, handle_parsing_errors=True


# === Refine SQL Command ===

def refineSQL_orig(llm = llm, query = None):
    system ='''
        Respond helpfully and accurately as possible.
        Filename = 'dataset'
        Column names = [Transaction_ID,Employee_ID,Employee_Name,Transaction_Date,Product_Name,Transaction_Amount,Customer_ID,Customer_Name]

        Noticed that Transaction_Date's datatype is integer, so give the data like 20240101, not '2024-01-01'

        Thought:Is this a SQL Command?, Is filename correct, Is this SQL Command relative to the column names of the file?, Could this SQL Command work? 
        Action: generate a SQL Command using column name refer to Input
        Observation: Generatived SQL Command result
        ... (repeat Thought/Action/Observation N times)

        Final Respond: A SQL Command that could directly interact with a SQL database, don't include any thoughts, assuming or explanation in Command

        Begin! Respond in SQL Command as possible
    '''
    human = '''{input}

        (reminder to respond in a SQL Command)'''

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system),
            ("human", human),
        ]
    )
    print("Refining ...")
    return llm.invoke(prompt.format(input=query))

def refineSQL(llm = llm, query = None, error=''):

    system = f'''
        Please correct the SQL Command error refer to this error message: {error}

        Return the corrected SQL Command, the format must be like 'SELECT ... FROM ... WHERE ...'.

    '''

    human = '''{input}

        (reminder to respond in a SQL Command)'''

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system),
            ("human", human),
        ]
    )
    print("Refining ...")
    return llm.invoke(prompt.format(input=query))

if __name__ == "__main__":

    # input = "1. how long is the word abcdefhjla?\n \
    #         2. 15 multiply 30?\n \
    #         3. Tell me a secret"
    # input = "how long is the word abcdefhjla?"
    import time

    while True:
        data = input("Message: ")
        if 'Exit' == data:
            break

        start = time.time()
        print(Agent_Executor.invoke({"input": data}))
        end = time.time()

        print(f"\nTotal time: {end - start}")
        print("\n\n")