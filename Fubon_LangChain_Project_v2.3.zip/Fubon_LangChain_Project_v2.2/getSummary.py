from langchain_core.prompts import ChatPromptTemplate

class getSummary:

    
    def __init__(self, llm):
        self.llm = llm
        self.datasets = []
        self.Input_Question = ""
    
    def store_dataset(self, dataset):

        if len(self.datasets) == 3:
            self.datasets.pop(0)
        self.datasets.append(dataset)

        # print(f"Dataset Type: {type(self.dataset)}")
        return dataset
    
    # Summarize the key characteristics of this datasets, Include basic statistics and data insights.
    def summary(self, msg):
        try:
            system = f'''
                I want you to act as a data scientist.
                Don't give me any code for programming.
                (If ask to do calculating, Just list all relative number, then compute step by step as example.
                    example:
                    Question: 1+1+2+3+4 = ?
                    Thought:
                    1+1 = 2,
                    2+2 = 4,
                    4+3 = 7,
                    7+4 = 11
                    Answer: 11)
                Here is raw data:
                ===
                {self.datasets[0].to_string(index=False)}
                ===
                '''

            human = '''{input}

                (Please respond in traditional chinese.)'''

            prompt = ChatPromptTemplate.from_messages(
                [
                    ("system", system),
                    ("human", human),
                ]
            )
            print("Summarizing ...")
            return self.llm.invoke(prompt.format(input=msg))
        except:
            return "無法做資料分析"

    def query(self, msg):
        try:

            if len(self.datasets) == 0:
                return "尚未有資料"
                
            fields = ""
            for i, dataset in enumerate(self.datasets):
                    table_name = f"table{i}"
                    locals()[table_name] = dataset
                    fields += (table_name + "|" + ", ".join(column for column in list(dataset.columns)) + "\n")


            system = f'''
                Expected a SQL Command for tables.

                May need to join the tables, When the required fields appear in more than two tables.
                table name | fields
                {fields}

                Examples:
                1.Input: 在業績資料中有哪些客戶是可以搜尋的，不要重複的姓名
                Answer: SELECT DISTINCT Customer_Name FROM 客戶表
                Explaination: No need to join
                
                2.Input: 我想搜尋客戶王曉明和客戶林丹雨在2023/06/08前交易金額<=30000的業績資料
                Answer: SELECT Customer_Name, Transaction_Date, Transaction_Amount FROM 業績表 JOIN 客戶表 ON 業績表.C_ID = 客戶表.Customer_ID WHERE Customer_Name IN ('王曉明', '林丹雨') AND Transaction_Date <= 20230608  AND Transaction_Amount <= 30000
                Explaination: Because 業績表 doesn't include field 'Customer_Name' , 業績表 needs to join 客戶表.

                Noticed that:
                1. Give the date field data like 20240101, not '2024-01-01' 
                2. If user say that don't want repeated data, use SELECT DISTINCT ...
                3. If user wants separate aggregated data like SUM(data) within a group, use SELECT XXX, ...  GROUP BY XXX, ...; , if not, don't use GROUP BY.
                4. Make SQL Command as short as possible.

                Check the format must be like SELECT ... FROM ... WHERE ...;, DOUBLE CHECK the notices and problems.
            '''

            human = '''{input}

                (Please respond a SQL Command)'''

            prompt = ChatPromptTemplate.from_messages(
                [
                    ("system", system),
                    ("human", human),
                ]
            )
            print("Processing ...")
            print(self.llm.invoke(prompt.format(input=msg)))
        
            return duckdb.query(query).df()

        except:
            return "需要更詳細的描述"
    
    def get_dataset(self):
        try:
            return self.datasets
        except:
            return "無法做資料分析"