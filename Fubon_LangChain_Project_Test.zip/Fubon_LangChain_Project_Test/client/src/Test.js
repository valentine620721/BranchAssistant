import { useState } from 'react'

import './Test.css'

export default function TestBox(){

    const [Clicked, setClicked] = useState(false);

    return(
        <div style={{width: "500px", height: "500px" }}>
            <div className="testbox">
                {Clicked && 
                    <div role="dialog" className="dialog-test">
                        <input type="checkbox"></input>
                    </div>
                }
                <div role="button" className="btn-test" onClick={() => setClicked(!Clicked)}>123</div>
            </div>
        </div>
    )
}