import './NavBar.css'

import axios from 'axios';
import React, { useContext, useState } from 'react';

// import DocUploader from './DocUploader';

import { NavBarContext } from './Context';
import { ChatSVG, FolderArrowUpSVG, FubonSVG, LockSVG, MagnifierSVG, PersonSVG, SettingSVG } from './SVG';


function NavBarLeft() {

    const [uploadOpen, setUploadOpen] = useState(false);
    const [settingOpen, setSettingOpen] = useState(false);

    const context = useContext(NavBarContext);

    return (
        <>
            <div className='navbar-left'>
                {/* <Nav defaultActiveKey="/" className="flex-column">
                <Nav.Link href="/">聊天室</Nav.Link>
                <Nav.Link eventKey="link-1">檔案上傳</Nav.Link>
                </Nav> */}
                <div role='button' className='navbar-item logo-container navbar-btn-style' onClick={() => {context.tab_setter([true, false, false, false, false])}}><ChatSVG/><span className='list-item'>聊天室</span></div>
                <div role='button' className={uploadOpen ? 'navbar-item logo-container navbar-btn-style setting-open' : 'navbar-item logo-container navbar-btn-style setting-close'} onClick={() => {setUploadOpen(!uploadOpen)}}><FolderArrowUpSVG/><span className='list-item'>檔案上傳</span></div>
                    {uploadOpen &&
                            <div className='setting-child'>
                                <div role='button'  onClick={() => {context.tab_setter([false, true, false, false, false])}}>Metadata上傳</div>
                            </div>
                    }
                <div role='button' className={settingOpen ? 'navbar-item logo-container navbar-btn-style setting-open' : 'navbar-item logo-container navbar-btn-style setting-close'} onClick={() => {setSettingOpen(!settingOpen)}}><SettingSVG/><span className='list-item'>參數設定</span></div>
                    {settingOpen &&
                        <div className='setting-child'>
                            <div role='button'  onClick={() => {context.tab_setter([false, false, true, false, false])}}>一般參數設定</div>
                            <div role='button'  onClick={() => {context.tab_setter([false, false, false, true, false])}}>連線參數設定</div>
                        </div>
                    }
                <div role='button' className='navbar-item logo-container navbar-btn-style' onClick={() => {context.tab_setter([false, false, false, false, true])}}><MagnifierSVG/><span className='list-item'>資料權限設定</span></div>
            </div>
        </>
    );
}

function NavBarTop() {

    const context = useContext(NavBarContext);

    const handleLogout = () => {
        context.auth_setter(false);
        context.user_setter('尚未登入');
        
        axios.post('http://localhost:5001/api/logout', {'token': localStorage.getItem('token')})
        localStorage.removeItem('token');

        document.location.reload();
    }

    return (
        <>
            <div className='navbar-top'>
                <div className='navbar-item'>
                    <FubonSVG />
                    <span style={{"lineHeight": "58px", "padding": "0 8px", "fontSize": "22px", "fontWeight": "bold", "letterSpacing": "2px", "verticalAlign": "bottom"}}>富邦數據查詢系統</span>
                </div>
                <div className='account-container'>
                    <div role='button' onClick={() => {context.resetPWD_setter(true);}} className='navbar-item logo-container'>
                    <LockSVG />
                    <span style={{"padding": "0 5px"}}>變更密碼</span>
                    </div>
                    <div className='navbar-item logo-container'>
                        <PersonSVG />
                        <span style={{"padding": "0 5px", "color": "#0093C1"}}>{context.user_state}</span>
                    </div>
                    <div role='button' onClick={handleLogout} className='navbar-item'>登出</div>
                </div>
            </div>
        </>
    );
}

export {NavBarLeft, NavBarTop};