import { ChonkyIconName, ChonkyIconProps } from 'chonky';
import { ChonkyIconFA } from 'chonky-icon-fontawesome';
import React from 'react';
import { FileSVG, FolderSVG } from './SVG';
const myIconMap = {
    [ChonkyIconName.folder]: <FolderSVG />,
    [ChonkyIconName.file]: <FileSVG />,
    [ChonkyIconName.text]: <FileSVG />,
    [ChonkyIconName.database]: <FileSVG />,
};
export const SelfIconFA = React.memo((props) => {
    const Icon = myIconMap[props.icon];
    if (Icon) {
        return <span>{Icon}</span>;
    }
    return <ChonkyIconFA {...props} />;
});