
import { useState } from 'react';
import axios from 'axios';

import './SettingPage.css'

function CommonSettingPage(){

    const handleSubmit = (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });

        // axios.post('http://127.0.0.1:5001/save_db_config', data)
        // .then(response => {

        //     console.log('成功:', response.data);

        // })
        // .catch(error => {

        //     console.error('錯誤:', error);
        // });
    
    }

    return(
        <>  
            <div className="setting-container">
                <h3>一般參數設定</h3>
                <form className="form-container" onSubmit={handleSubmit}>
                    <div className="setting-form">
                        <div>
                            <label htmlFor="model">選擇模型:</label>
                            <select id="model" name="model">
                                <option value="GPT4">GPT4</option>
                                <option value="Gemma2">Gemma2</option>
                            </select>
                        </div>
                    </div>
                    <div style={{marginLeft: 'auto', marginRight: 'auto', width: 'fit-content'}}>
                        <button type="submit" >儲存</button>
                    </div>
                </form>
            </div>
        </>
    )
}

export default CommonSettingPage;