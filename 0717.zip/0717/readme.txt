Dear宇恆

1.昨天說的三層結構沒有完成，今天延續新prompt的測試詢問的時間拉有點長。
2.目前的prompt問原本的問題，會出現一些錯誤狀況，原本答對的改後會答錯。
3.tables.txt按照原本的說的，改了幾個日期的datatype，目前測的問題也會出錯。
4.第2與3的出現的問題，我週五跟你討論一下。
5.附上的檔案是改過prompt的LangchainAgent、oracle的tables.txt
