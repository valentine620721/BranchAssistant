from langchain_core.prompts import ChatPromptTemplate

class getSummary:

    
    def __init__(self):
        pass
    
    def store_dataset(self, dataset):
        self.dataset = dataset
        print(f"Dataset Type: {type(self.dataset)}")
        return self.dataset
    
    # Summarize the key characteristics of this datasets, Include basic statistics and data insights.
    def summary(self, llm):
        try:
            system = f'''
                I want you to act as a data scientist.
                Please do the data analysis and give me a professional report.
                Please respond in traditional chinese.

                '''

            human = '''{input}

                (reminder to respond a data analysis report)'''

            prompt = ChatPromptTemplate.from_messages(
                [
                    ("system", system),
                    ("human", human),
                ]
            )
            print("Summarizing ...")
            return llm.invoke(prompt.format(input=self.dataset.to_string(index=False)))
        except:
            return "尚未有資料可以總結"
    
    def get_dataset(self):
        try:
            return self.dataset
        except:
            return "尚未有資料可以總結"