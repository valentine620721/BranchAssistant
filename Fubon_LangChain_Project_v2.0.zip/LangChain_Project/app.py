from flask import Flask, request, render_template, make_response, jsonify
from flask_cors import CORS, cross_origin
from getCustomerDataset import  getCsvDataset
import time

from Langchain_Agent import Agent_Executor


# Global Variables: 儲存資料來渲染表格
Ai_response = ""

# Flask App
app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False
CORS(app)

# Backend API
@app.route('/get_answer', methods=['POST', 'OPTIONS'])
@cross_origin()
def process_input():

    global Ai_response

    header={
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'POST'
    }

    data = request.get_json()
    print(f'server receive data from User input: {data}')
    user_input = data.get('inputText') #等同於 data['inputText']
    try:
        Ai_response = Agent_Executor.invoke({"input": user_input})['output']
        
        if not isinstance(Ai_response, str):
            if (Ai_response is None or len(Ai_response) == 0):
                result = '資料不存在'
            # result = Ai_response.to_string(index=False)
            result = "完成資料搜尋"
            return make_response(jsonify({'response': result, 'data': Ai_response.to_json(orient='records')}), 200, header)
        
        result = Ai_response

    except Exception as e:
        result = "我不知道怎麼回答"
        print(f'\nThe error message is here: {e}')
    
    return make_response(jsonify({'response': result}), 200, header)

@app.route("/table")
def table():
    return render_template('table.html', dataset=Ai_response.to_dict(orient='records'))
    

@app.after_request
def after_request(response):
    response.access_control_allow_origin = "*"
    return response

if __name__ == "__main__":
    app.run(debug=True, port=5001)










