
from langchain.pydantic_v1 import BaseModel, Field
from langchain.tools import BaseTool, StructuredTool, tool

from getCustomerDataset import  getCsvDataset

from getSummary import getSummary
from getFAISS import getFAISS

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import AIMessage

from langchain.agents import create_structured_chat_agent
from langchain.agents import AgentExecutor

from langchain_community.vectorstores import FAISS
from langchain_community.embeddings import OllamaEmbeddings

import re
import os
import json

from langchain_community.llms import Ollama

class LangchainAgent:

    def __init__(self):
        self.set_llm()
        self.set_prompt()

        self.embeddings = OllamaEmbeddings(model="aerok/zpoint_large_embedding_zh") # shaw/dmeta-embedding-zh
    
    def set_llm(self):
        with open('./config/config.json', 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        self.llm = Ollama(model = config['model'], temperature = int(config['temperature']), top_k = int(config['topk']))
        self.table_meta_topk = config["table_meta_topk"]
        self.keywords_topk = config["keywords_topk"]
        self.question_topk = config["question_topk"]

    def set_prompt(self):
        with open(f'./user_database/prompt.json', 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        self.parse_question_prompt = data['parse_question']
        self.generate_tables_name_prompt = data['generate_tables_name']
        self.generate_SQL_prompt = data['generate_SQL']

    def save_prompt(self, case, prompt):

        with open(f'./user_database/prompt.json', 'r', encoding='utf-8') as f:
            data = json.load(f)
        data[case] = prompt

        with open(f'./user_database/prompt.json', 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)

        if case == "parse_question":
            self.parse_question_prompt = prompt
        
        elif case == "generate_tables_name":
            self.generate_tables_name_prompt = prompt
        
        elif case == "generate_SQL":
            self.generate_SQL_prompt = prompt

    def get_fields(self, lines, table_name):    
        result = ''
        for field in lines:
            if ((table_name.strip()) in field.split('|')[0]):
                result += (field.split('.')[-1]+'\n')

        return result


    def get_metadata(directory):    
        with open(directory+"table_meta.txt", 'r', encoding='utf-8') as file:
            result = file.read()
        
        return result

    def get_tables_name(directory):
        name_list = []
        for csv in os.listdir(directory):
            csv_name, csv_extentsion = csv.split('.')
            if  csv_extentsion == "csv":
                name_list.append(csv_name)
        
        return ", ".join(name for name in name_list)
        
    def parse_question(self, msg):

        human = '''{input}'''

        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", self.parse_question_prompt),
                ("human", human),
            ]
        )
        print("Processing ...")
        return self.llm.invoke(prompt.format(input=msg))

    def generate_tables_name(self, table_inform, msg):
        system = f'''
            {self.generate_tables_name_prompt}

            {table_inform}
        '''

        human = '''{input}'''

        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system),
                ("human", human),
            ]
        )
        print("Processing ...")
        return self.llm.invoke(prompt.format(input=msg))


    def generate_SQL(self, table_inform, msg):
        print("input: " + msg + "\n")
        system_sql = f'''
            {table_inform}

            {self.generate_SQL_prompt}
        
        '''

        human_sql = '''{input}

            (Please respond a SQL Command)'''

        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system_sql),
                ("human", human_sql),
            ]
        )
        print("Processing ...")
        return self.llm.invoke(prompt.format(input=msg))

    def rewrite_SQL(self, database, msg):
        # print("input: " + msg + "\n")
        system_sql = f'''
        Rewrite in {database} syntax, and don't rewrite the table name.
        Make sure the syntax is correct, and the query result will be the same.

        Answer as format 
        ```sql
            SELECT ... FROM ...;
        ```, without explanation.
        '''

        # print('\n\n' + system_sql + '\n')

        human_sql = '''{input}
        (Please respond a SQL Command)
        '''

        prompt = ChatPromptTemplate.from_messages(
            [
                ("system", system_sql),
                ("human", human_sql),
            ]
        )
        print("Rewriting ...")
        return self.llm.invoke(prompt.format(input=msg))

    def query_by_SQL(self, username, chatId, auth_tables, question, keyword):

        directory = './database/'
        file_name = "/database_table_meta.txt"
        col_file_name = "/col_meta.txt"

        pattern = r'\d+\.\s*(.*?)\n'
        keywords_list = re.findall(pattern, keyword)
        keywords_list = [keyword.strip() for keyword in keywords_list] 

        table_list = []
        for database in os.listdir(directory):
            try:
                with open(directory + database + file_name, 'r', encoding='utf-8') as file:
                    lines = file.read().split('\n')
                    table_list += lines[1:]
            except:
                pass

        table_list = [item for item in table_list if item != '']

        table_vectors = FAISS.from_texts(table_list, self.embeddings)
        table_inform_list = []
        for keyword in keywords_list:
            for result in table_vectors.similarity_search_with_score(keyword, k = int(self.table_meta_topk)):
                table_inform_list.append(result[0].page_content)

        tables_set = set(table_inform_list)
        database_inform = 'database | table | metadata\n' + '\n'.join(sorted(list(tables_set)))

        print(database_inform)
        print("\n\n")

        tables = self.generate_tables_name(database_inform, question)

        print(tables)

        selected_inform = tables.split(';')
        selected_driver = selected_inform[-1].split(':')[-1].strip()
        selected_tables = selected_inform[0].split(':')[-1]
        
        with open(directory + selected_driver + col_file_name, 'r', encoding='utf-8') as file:
            lines = file.read().split('\n')

        col_list = []
        for table_name in selected_tables.split(','):
            for col in lines:
                if ((table_name.strip()) in col.split('|')[0]):
                    col_list.append(col)

        col_vectors = FAISS.from_texts(col_list, self.embeddings)

        for_join_keyword_list = ['代碼', '代號', 'ID']

        col_inform_list = []
        
        for keyword in for_join_keyword_list:
            print(f"====={keyword}=====")
            for result in col_vectors.similarity_search_with_score(keyword, k = int(self.keywords_topk)):
                col_inform_list.append(result[0].page_content)
                print(result[0].page_content)

        print(f"====={question}=====")
        for result in col_vectors.similarity_search_with_score(question, k = int(self.question_topk)):
            col_inform_list.append(result[0].page_content)
            print(result[0].page_content)

        selected_columns = set(col_inform_list)

        # print(selected_columns)

        table_inform = f'table_name: {selected_tables}\n\n'
        for table_name in selected_tables.split(','):
            table_inform += f"{lines[0].replace('table_name', table_name.strip())}\n"
            if table_name.strip() != '':
                table_inform += self.get_fields(selected_columns, table_name) + '\n'

        print("\n\n")
        print(table_inform)
        sqlCommand = self.generate_SQL(table_inform, question + '\n' + keyword)
        sqlCommand = sqlCommand.replace('`', '')
        sqlCommand = sqlCommand[sqlCommand.find('SELECT'): sqlCommand.find(';')]
        print(f"Origin:\n{sqlCommand}")

        sqlCommand = self.rewrite_SQL(selected_driver, sqlCommand)
        sqlCommand = sqlCommand[sqlCommand.find('SELECT'): sqlCommand.find(';')]
        print(f"{selected_driver}:\n{sqlCommand}")

        with open(f'./user_data/{username}/chat.json', 'r', encoding='utf-8') as f:
                data = json.load(f)
        
        data['q_history'][chatId].append(question)
        data['sql_history'][chatId].append(sqlCommand)
        data['db_history'][chatId].append([selected_driver, 'TestDB'])

        with open(f'./user_data/{username}/chat.json', 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False)

        try:
            dataset = getCsvDataset.dataset_query_sql(directory + selected_driver, sqlCommand, auth_tables = auth_tables)
        
        except:
            dataset = []


        return_data = {
            'question': question,
            'sqlCommand': sqlCommand,
            'selected_driver': selected_driver,
            'selected_database': 'TestDB',
            'dataset': dataset
        }
        
        return return_data
