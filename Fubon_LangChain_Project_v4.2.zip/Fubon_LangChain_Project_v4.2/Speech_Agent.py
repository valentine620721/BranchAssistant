from faster_whisper import WhisperModel

try:
    model = WhisperModel('./faster-whisper-large-v2')
except:
    pass

def transcribe(file):
    segments, info = model.transcribe(file, beam_size=5)
    text = ''

    for segment in segments:
        text += "[%.2fs -> %.2fs] %s\n" % (segment.start, segment.end, segment.text)
    
    return text