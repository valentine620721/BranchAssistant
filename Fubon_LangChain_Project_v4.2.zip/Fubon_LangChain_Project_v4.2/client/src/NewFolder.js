
import { useState, useContext } from 'react';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import axios from 'axios';

import './DocUploader.css'
import { FolderContext } from './Context';

function NewFolder() {
  const [show, setShow] = useState(false);
  const [inputValue, setInputValue] = useState('');

  const context = useContext(FolderContext);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  // Handle input change event
  const handleInputChange = (event) => {
    setInputValue(event.target.value); // Update state with the input value
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    axios.post('http://127.0.0.1:5001/new_folder', {'folderName': inputValue, 'subpath': context.path_state})
    .then((response) => {
        console.log(response.data);
        context.get_folders(context.path_state);
    })
    .catch((error) => {
        console.error(error);
    });
    setShow(false);
  };



  
  return (
    <>
      <button onClick={handleShow}>
        新增資料夾
      </button>

      <Modal show={show} onHide={handleClose}>
        <form id="formfile" onSubmit={handleSubmit}>
            <Modal.Header closeButton>
            <Modal.Title>
              輸入資料夾名稱:
            </Modal.Title>
            </Modal.Header>
            <Modal.Body>            
                <input type="text" value={inputValue} onChange={handleInputChange}/>
            </Modal.Body>
            <Modal.Footer>
            <Button variant="primary" type='submit'>
                確認
            </Button>
            </Modal.Footer>
        </form>
      </Modal>
    </>
  );
}

export default NewFolder;
