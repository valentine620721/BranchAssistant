import { useState, useEffect } from 'react';
import axios from 'axios';

import { UploadSVG } from './SVG';

import './DocUploadPage.css'
import DocUploader from './DocUploader';
import NewFolder from './NewFolder';
import { FolderContext } from './Context';

function DocUploadPage() {
  const [show, setShow] = useState(false);

  const [file, setFile] = useState([]);

  const [folder, setFolder] = useState([]);

  const [path, setPath] = useState("");

  const [select, setSelect] = useState(false);

  const generate_folders = (content) => {
    let rows = []
    for (let i=0; i < content.length; i++) {
        if(content[i]['type'] === 'directory'){
            rows.push(<><input subpath={content[i]['path']} className='check2delete' type="checkbox"/><input id={'file'+i} subpath={content[i]['path']} type="button" name="app" onClick={handleButtonClick}/><label style={{color: '#000'}} htmlFor={'file'+i}>{content[i]['name']}</label></>);
        }
        else{
            // 可以新增下載檔案功能，onclick call 後端api下載
            rows.push(<><input subpath={content[i]['path']} className='check2delete' type="checkbox"/><input id={'file'+i} subpath={content[i]['path']} type="button" name="app" /><label style={{color: '#000'}} htmlFor={'file'+i}>{content[i]['name']}</label></>);
        }
    }
    return rows
  }
  const get_folders = () => {

        axios.post('http://127.0.0.1:5001/check_folder', {'subpath': path})
        .then((response) => {
            setFolder(generate_folders(response.data['content']));
        })
        .catch(() => {
            alert("無此資料夾或檔案");
        });
  } 


  useEffect(() => {
    get_folders(path);
    setSelect(false);
  }, [path]);

  useEffect(() => {
    try{
        let checkboxs = document.getElementsByClassName('check2delete');
        if(select){
            for(let i=0; i < checkboxs.length; i++){
                checkboxs[i].setAttribute("style", "display: block");
            }
        }
        else{
            for(let i=0; i < checkboxs.length; i++){
                checkboxs[i].setAttribute("style", "display: none");
                checkboxs[i].checked = false;
            }
        }
    } catch(e){
        console.log(e);
    }
  }, [select])

  const handleButtonClick = (e) => {
        setPath(e.target.getAttribute("subpath"));
        // get_folders(e.target.id);
  };

  const handleBtnSelect = () => {
        setSelect(!select);
    };

  const handleBtnDelete = () => {
        try{
            let delete_list = [];
            let checkboxs = document.getElementsByClassName('check2delete');
            for(let i=0; i < checkboxs.length; i++){
                    if(checkboxs[i].checked){
                        delete_list.push(checkboxs[i].getAttribute('subpath'));
                        checkboxs[i].checked = false;
                    }
            }
            if(delete_list.length !== 0){
                axios.post('http://127.0.0.1:5001/delete_metadata', {'subpath': delete_list})
                .then((response) => {
                    get_folders(path);
                    console.log(response.data);
                })
                .catch(() => {
                    alert("無此資料夾或檔案");
                });
            }
        } catch(e){
            console.log(e);
        } 
    };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(file);
    if(file != null){
        console.log("submit");
        const formData = new FormData(e.target);
        for (let i = 0; i < file.length; i++) {
            formData.append('file', file[i]);
        }

        axios.post('http://127.0.0.1:5001/upload_doc', formData)
        .then((response) => {
            console.log(response.data);
            alert('上傳成功！')
        })
        .catch((error) => {
            console.error(error);
            alert('上傳失敗 !')
        });
        setShow(false);
        setFile(null);
    }
  };

    // select option 要 call api 知道有哪些資料庫
    // 上傳前要檢查有沒有選擇資料庫，沒有就 alert 請新增或選擇資料庫
    // 上傳要讓後端知道現在選擇的資料庫
  
  return (
    <>
        <div className='box-center'>
            <div className='box-doc'>
                
                {!show && <>
                <div className='btn-sort'>
                    <FolderContext.Provider value={{
                        path_state: path,
                        path_setter: setPath,
                        get_folders: get_folders
                    }}>
                        <NewFolder/>
                        <DocUploader/>
                    </FolderContext.Provider>
                    <button onClick={() => {handleBtnSelect()}}>{select ? '取消選取' :'選取'}</button>
                    <button onClick={() => handleBtnDelete()}>刪除</button>
                </div>
                
                <div className='tab_css'>
                    {folder}
                </div>
            
                <button onClick={() => {setPath("");}}>
                        回到主資料夾
                </button>
                </>
                }

                {show && <>
                    <h3>點擊圖示，並上傳檔案</h3>
                    <form id="UploadForm" encType="multipart/form-data" onSubmit={handleSubmit}>         
                    <input type="file" id="fileUpload" multiple onChange={(e) => {setFile(e.target.files);}}/>
                    <label htmlFor="fileUpload">
                            {file.length === 0 && <UploadSVG/> }
                            <ul>
                            {file.length !== 0 && 
                                Array.from(file).map(
                                    (f) => {
                                        return (<li key={f.name}> {f.name} </li>)
                                    }
                                )
                            }
                            </ul>
                    </label>
                </form>
                <div className="" style={{position: 'relative', width: '100%'}}>
                    <button style={{position: 'absolute', left: 0}} onClick={() => {setShow(false)}}>
                        上一步
                    </button>
                    <button variant="primary" type='submit' style={{display: 'block',  margin: '0 auto'}}>
                        上傳
                    </button>
                </div></>}
            </div>
        </div>
    </>
  );
}

export default DocUploadPage;