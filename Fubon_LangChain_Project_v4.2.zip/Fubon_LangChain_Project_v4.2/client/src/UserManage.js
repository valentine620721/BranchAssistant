import React, { useEffect, useState } from 'react';
import axios from 'axios';

import './UserList.css'
import './SettingPage.css'


const initialUsers = [
   {username: '無資料', databases: '無資料' },
];

const UserManage = () => {
  const [users, setUsers] = useState(initialUsers);
  const [editingUser, setEditingUser] = useState(null);
  const [newUser, setNewUser] = useState(null);
  const [newDatabases, setNewDatabases] = useState('');

  const handleEdit = (user) => {
    setEditingUser(user);
    setNewDatabases(user.databases);
  };

  const handleNewUser = (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);
    const data = {};
    formData.forEach((value, key) => {
        data[key] = value;
    });

    axios.post('http://localhost:5001/new_user', data)
    .then(() => {
    })
  };

  const handleSave = () => {
    const updatedUsers = users.map((user) =>
      user.username === editingUser.username ? { ...user, databases: newDatabases } : user
    );

    axios.post('http://localhost:5001/auth_update', {'username': editingUser.username, 'databases': newDatabases})
    .then(() => {
        setUsers(updatedUsers);
        setEditingUser(null);
    })
  };

  const handleCancel = () => {
    setEditingUser(null);
  };

  useEffect(() => {
    axios('http://localhost:5001/user_list')
    .then(function (response){
        setUsers(response.data.users);
    })
  }, [])

  return (
    <>
        <div className='userlist-container'>
        <h1>使用者管理清單</h1>
        <table>
            <thead>
            <tr>
                <th>序號</th>
                <th>使用者名稱</th>
                <th>使用者類型</th>
                <th>單位</th>
                <th>可使用的資料表</th>
                <th>最後登入時間</th>
                <th><button onClick={() => setNewUser("ff")}>新增使用者</button></th>
            </tr>
            </thead>
            <tbody>
            {users.map((user, id) => (
                <tr key={id+1}>
                <td>{id+1}</td>
                <td>{user.username}</td>
                <td></td>
                <td></td>
                <td>{user.databases}</td>
                <td></td>
                <td>
                    <button onClick={() => handleEdit(user)}>編輯</button>
                </td>
                </tr>
            ))}
            </tbody>
        </table>
        </div>
        {newUser && (
            <div className="userlist-overlay" >
                <div className='userlist-update-container'>
                  <form onSubmit={handleNewUser}>
                    <div className="setting-form">
                      <div>
                          <label htmlFor="username">使用者名稱：</label>
                          <input
                              id = "username"
                              name="username"
                              required
                          />
                      </div>
                      <div>
                          <label htmlFor="email">信箱：</label>
                          <input
                              id = "email"
                              name="email"
                              required
                          />
                      </div>
                      <div>
                          <label htmlFor="pwd">密碼：</label>
                          <input
                              id = "pwd"
                              name="pwd"
                              type="password"
                              required
                          />
                      </div>
                      <div>
                          <input
                              id = "group"
                              name="group"
                              type="checkbox"

                              style={{marginRight: "5px"}}
                          />
                          <label htmlFor="group">Superuser</label>
                      </div>
                    </div>
                    <div className="align-center">
                        <button type="submit">完成</button>
                        <button onClick={() => setNewUser(null)}>取消</button>
                    </div>
                  </form>
                </div>
            </div>
        )}
        {editingUser && (
            <div className="userlist-overlay" >
                <div className='userlist-update-container'>
                    <h2>{"編輯 "+editingUser.username+" 可使用的資料表"}</h2>
                    <textarea
                        rows={3}
                        value={newDatabases}
                        onChange={(e) => setNewDatabases(e.target.value)}
                    />
                    <div>
                        <button onClick={handleSave}>完成</button>
                        <button onClick={handleCancel}>取消</button>
                    </div>
                </div>
            </div>
        )}
    </>
  );
};

export default UserManage;