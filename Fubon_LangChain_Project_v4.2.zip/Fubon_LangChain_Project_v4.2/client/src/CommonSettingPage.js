
import { useState, useEffect } from 'react';
import axios from 'axios';

import './SettingPage.css'

function CommonSettingPage(){

    const [config, setConfig] = useState({    
        "model": "",
        "temperature": 0,
        "topk": 0,
        "table_meta_topk": 0,
        "keywords_topk": 0,
        "question_topk": 0
    });

    const handleChange = (e) => {
        const config_copy = {...config}; 
        config_copy[e.target.id] = e.target.value;
        setConfig(config_copy);
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        
        const token = localStorage.getItem('token');
        const formData = new FormData(e.target);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        data['token'] = token;

        axios.post('http://127.0.0.1:5001/save_config', data)
        .then(response => {

            console.log('成功:', response.data);

        })
        .catch(error => {

            console.error('錯誤:', error);
        });
    
    }

    useEffect(() => {
        const token = localStorage.getItem('token');
    
        axios.post('http://localhost:5001/get_config', {'token': token})
        .then(function (response){
            // console.log(response.data.result);
            setConfig(response.data.result);
        })
        .catch((error) => {
            console.log(error);
        })
    }, []);

    return(
        <>  
            <div className="setting-container">
                <form className="form-container" onSubmit={handleSubmit}>
                    <div className="setting-form">
                        <div>
                            <label htmlFor="model">選擇模型:</label>
                            <select id="model" name="model" value={config.model} onChange={handleChange}>
                                <option value="GPT4">GPT4</option>
                                <option value="gemma2">Gemma2</option>
                            </select>
                        </div>
                        <div>
                            <label htmlFor="temperature">temperature：</label>
                            <input
                                id = "temperature"
                                name="temperature"
                                type="number"
                                required
                                value = {config.temperature}
                                onChange={handleChange}
                            />
                        </div>
                        <div>
                            <label htmlFor="topk">topk：</label>
                            <input
                                id = "topk"
                                name="topk"
                                type="number"
                                required
                                value = {config.topk}
                                onChange={handleChange}
                            />
                        </div>
                        <div>
                            <label htmlFor="table_meta_topk">table_meta_topk：</label>
                            <input
                                id = "table_meta_topk"
                                name="table_meta_topk"
                                type="number"
                                required
                                value = {config.table_meta_topk}
                                onChange={handleChange}
                            />
                        </div>
                        <div>
                            <label htmlFor="keywords_topk">keywords_topk：</label>
                            <input
                                id = "keywords_topk"
                                name="keywords_topk"
                                type="number"
                                required
                                value = {config.keywords_topk}
                                onChange={handleChange}
                            />
                        </div>
                        <div>
                            <label htmlFor="question_topk">question_topk：</label>
                            <input
                                id = "question_topk"
                                name="question_topk"
                                type="number"
                                required
                                value = {config.question_topk}
                                onChange={handleChange}
                            />
                        </div>
                    </div>
                    <div style={{marginLeft: 'auto', marginRight: 'auto', width: 'fit-content'}}>
                        <button type="submit" >儲存</button>
                    </div>
                </form>
            </div>
        </>
    )
}

export default CommonSettingPage;