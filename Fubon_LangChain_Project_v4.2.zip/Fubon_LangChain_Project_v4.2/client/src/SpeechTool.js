import { useState } from "react";
import { UploadSVG } from "./SVG";
import axios from "axios";

import './SpeechTool.css'

export default function SpeechTool(){

    const [result, setResult] = useState('');
    const [file, setFile] = useState([]);
    const [setting, setSetting] = useState('auto');

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log(file);
        if(file != null){
            console.log("submit");
            const formData = new FormData(e.target);
            for (let i = 0; i < file.length; i++) {
                formData.append('file', file[i]);
            }
            setSetting('none');
            setResult('處理中...');
    
            axios.post('http://127.0.0.1:5001/upload_speech', formData)
            .then((response) => {
                setResult(response.data.result);
                setSetting('auto');
            })
            .catch((error) => {
                console.error(error);
                alert('上傳失敗 !')
            });
        }
      };

    return(
        <>
            <div className='box-doc'>
                <h3>點擊圖示，並上傳檔案</h3>
                <form id="UploadForm" encType="multipart/form-data" onSubmit={handleSubmit}>         
                    <input type="file" id="fileUpload" multiple onChange={(e) => {setFile(e.target.files); setResult('');}}/>
                    <label htmlFor="fileUpload" style={{overflowY: 'auto', pointerEvents: setting}}>
                            {file.length === 0 && <UploadSVG/> }
                            <div style={{whiteSpace: "pre-line", overflowY: 'auto'}}>
                                {file.length !== 0 && 
                                    result
                                }
                            </div>
                    </label>
                    <button variant="primary" type='submit' style={{display: 'block',  margin: '0 auto'}}>
                        上傳
                    </button>
                </form>
            </div>
        </>
    )
}