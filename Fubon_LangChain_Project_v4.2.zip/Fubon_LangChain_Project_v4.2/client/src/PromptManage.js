
import { useState, useEffect } from 'react';
import axios from 'axios';

import './SettingPage.css'

function PromptManage(){

    const [prompt, setPrompt]  = useState({"parse_question": "", "generate_tables_name": "", "generate_SQL": ""});

    const textareaOnChange = (e) => {
        setPrompt(e.target.value);
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        
        const token = localStorage.getItem('token');
        const formData = new FormData(e.target);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });
        data['token'] = token;

        axios.post('http://127.0.0.1:5001/save_prompt', data)
        .then(response => {

            console.log('成功:', response.data);

        })
        .catch(error => {

            console.error('錯誤:', error);
        });
    
    }

    useEffect(() => {
        axios.post('http://127.0.0.1:5001/get_prompt', {})
        .then(response => {

          setPrompt(response.data.data);

        })
        .catch(error => {

            console.error('錯誤:', error);
        });
      }, [])



    return(
        <>  
            <div className="setting-container">
                <form className="form-container" onSubmit={handleSubmit}>
                    <div className="setting-form" style={{"width": "100%", "align-items": "start", "flex-direction": "row", "justify-content": "space-between"}}>
                        <div className='setting-prompt'>
                            <label htmlFor="parse-question"><h3>解析問題：</h3></label>
                            <textarea className='setting-textarea' id="parse-question" name="parse-question" rows={10} value={prompt["parse_question"]} onChange={textareaOnChange} ></textarea>
                        </div>
                        <div className='setting-prompt'>
                            <label htmlFor="generate-tables-name"><h3>選擇要使用的資料庫和資料表:</h3></label>
                            <textarea className='setting-textarea' id="generate-tables-name" name="generate-tables-name" rows={10} value={prompt["generate_tables_name"]} onChange={textareaOnChange}></textarea>
                        </div>
                        <div className='setting-prompt'>
                            <label htmlFor="generate-SQL"><h3>生成 SQL 語句:</h3></label>
                            <textarea className='setting-textarea' id="generate-SQL" name="generate-SQL" rows={10} value={prompt["generate_SQL"]} onChange={textareaOnChange} ></textarea>
                        </div>
                    </div>
                    <div style={{marginLeft: 'auto', marginRight: 'auto', width: 'fit-content'}}>
                        <button type="submit" >儲存</button>
                    </div>
                </form>
            </div>
        </>
    )
}

export default PromptManage;