from langchain.pydantic_v1 import BaseModel, Field
from langchain.tools import BaseTool, StructuredTool, tool

from getCustomerDataset import  getCsvDataset

from getSummary import getSummary
from getFAISS import getFAISS

from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.messages import AIMessage

from langchain.agents import create_structured_chat_agent
from langchain.agents import AgentExecutor

import os

# === LLM ===
from langchain_community.llms import Ollama

# llm = Ollama(model = "llama3", temperature = 0, num_predict=320)
llm = Ollama(model = "mistral", temperature = 0.2)

SummaryFunc = getSummary(llm) # 宣告一個儲存資料和做總結的物件
RetrievalQA = getFAISS(llm)


def get_fields(directory):    
    with open(directory+"tables.txt", 'r') as file:
        result = file.read()
    
    return result

def get_tables_name(directory):
    name_list = []
    for csv in os.listdir(directory):
        csv_name, csv_extentsion = csv.split('.')
        if  csv_extentsion == "csv":
            name_list.append(csv_name)
    
    return ", ".join(name for name in name_list)


def reload():
    # === Calculator ===
    class CalculatorInput(BaseModel):
        a: int = Field(description="first number")
        b: int = Field(description="second number")


    def multiply(a: int, b: int) -> int:
        """Multiply two numbers."""
        return a * b


    calculator = StructuredTool.from_function(
        func=multiply,
        name="calculator",
        description="multiply numbers",
        args_schema=CalculatorInput,
        return_direct=True,
        # coroutine= ... <- you can specify an async method if desired as well
    )

    # === Get Word Length ===
    class WordLengthInput(BaseModel):
        word: str = Field(description="a word or a string")


    def get_word_length(word: str) -> int:
        return len(word)

    getWordLength = StructuredTool.from_function(
        func=get_word_length,
        name="getWordLength",
        description="Returns the length of a word",
        args_schema=WordLengthInput,
        return_direct=True,
        # coroutine= ... <- you can specify an async method if desired as well
    )

    # === searchOracleInput ===
    class SearchOracleInput(BaseModel):
        sqlCommand: str = Field(description=f'''
        Expected a SQL Command for Oracle.
        
        May need to join the tables, When the required fields appear in more than two tables.
        table name | fields
        {get_fields("./database/Oracle/")}

        Relationship: 業績表.E_ID = 員工表.Employee_ID, 業績表.C_ID = 客戶表.Customer_ID

        Examples:
        1.Input: 在業績資料中有哪些客戶是可以搜尋的，不要重複的姓名
        Answer: SELECT DISTINCT Customer_Name FROM 客戶表
        Explaination: No need to join
        
        2.Input: 我想搜尋客戶王曉明和客戶林丹雨在2023/06/08前交易金額<=30000的業績資料
        Answer: SELECT Customer_Name, Transaction_Date, Transaction_Amount FROM 業績表 JOIN 客戶表 ON 業績表.C_ID = 客戶表.Customer_ID WHERE Customer_Name IN ('王曉明', '林丹雨') AND Transaction_Date <= 20230608  AND Transaction_Amount <= 30000
        Explaination: Because 業績表 doesn't include field 'Customer_Name' , 業績表 needs to join 客戶表.

        3.Input: 我想搜尋在2023/02/24前，員工吳光磊跟客戶王曉明的交易，金額>20000的業績資料
        Answer: SELECT Customer_Name, Employee_Name, Transaction_Amount FROM 業績表 JOIN 員工表 ON 業績表.E_ID = 員工表.Employee_ID JOIN 客戶表 ON 業績表.C_ID = 客戶表.Customer_ID WHERE (Customer_Name = '王曉明' AND Employee_Name = '吳光磊') AND Transaction_Date <= 20230224 AND Transaction_Amount > 20000
        Explaination: Because 業績表 doesn't include field 'Employee_Name', 'Customer_Name' , 業績表 needs to join 員工表 and 客戶表.

        Noticed that:
        1. Give the date field data like 20240101, not '2024-01-01' .
        2. If user say that don't want repeated data, use SELECT DISTINCT ...
        3. If user wants separate aggregated data like SUM(data) within a group, use SELECT XXX, ...  GROUP BY XXX, ...; , if not, don't use GROUP BY.
        4. Make SQL Command as short as possible.

        Examples:
        1.  Input: 請給我每個員工的總業績，需包含姓名欄位
            Answer: SELECT Employee_ID, Employee_Name, SUM(Transaction_Amount) FROM ... GROUP BY Employee_ID, Employee_Name

        
        Check the format must be like SELECT ... FROM ... WHERE ...;, DOUBLE CHECK the notices and examples.
        ''')

    def search_from_oracle(sqlCommand: str) -> str:
        # 加入 API， return 查詢結果
        print(sqlCommand)
        return SummaryFunc.store_dataset(getCsvDataset.dataset_query_sql("./database/Oracle", llm, sqlCommand))
        # return "OK"

    searchFromFile = StructuredTool.from_function(
        func=search_from_oracle,
        name="search from Oracle",
        description=f'''Search for the desired data from Oracle using SQL command and returns the search results. May need use Join, focus on description,
                        Table list: {get_tables_name("./database/Oracle")}
                        ''',
        args_schema=SearchOracleInput,
        return_direct=True,
        # coroutine= ... <- you can specify an async method if desired as well
    )

    # === searchFileInput ===
    class SearchFileInput(BaseModel):
        sqlCommand: str = Field(description=f'''
        Expected a SQL Command for file.

        May need to join the tables, When the required fields appear in more than two tables.
        table name | fields
        {get_fields("./database/File/")}

        Noticed that:
        1. Give the date field data like 20240101, not '2024-01-01' 
        2. If user say that don't want repeated data, use SELECT DISTINCT ...
        3. If user wants separate aggregated data like SUM(data) within a group, use SELECT XXX, ...  GROUP BY XXX, ...; , if not, don't use GROUP BY.
        4. Make SQL Command as short as possible.

        Example:
        1.  Prompt: 我想搜尋在2023/09/22後 新聞數量最多的五個新聞
            Answer: SELECT * FROM ... WHERE 起始日期 > 20230922 ORDER BY 新聞數量 DESC LIMIT 5

        Check the format must be like SELECT ... FROM ... WHERE ...;, DOUBLE CHECK the notices and problems.
        ''')

    def search_from_file(sqlCommand: str) -> str:

        return SummaryFunc.store_dataset(getCsvDataset.dataset_query_sql("./database/File", llm, sqlCommand))

    searchFromNews = StructuredTool.from_function(
        func=search_from_file,
        name="search from file",
        description=f'''Search for the desired data from File using SQL command and returns the search results.
                        Table list: {get_tables_name("./database/File")}''',
        args_schema=SearchFileInput,
        return_direct=True,
        # coroutine= ... <- you can specify an async method if desired as well
    )

     # === searchSQLInput ===
    class SearchSQLInput(BaseModel):
        sqlCommand: str = Field(description=f'''
        Expected a SQL Command.
        
        May need to join the tables, When the required fields appear in more than two tables.
        table name | fields
        {get_fields("./database/SQL/")}

        Noticed that:
        1. Give the date field data like 20240101, not '2024-01-01' .
        2. If user say that don't want repeated data, use SELECT DISTINCT ...
        3. If user wants separate aggregated data like SUM(data) within a group, use SELECT XXX, ...  GROUP BY XXX, ...; , if not, don't use GROUP BY.
        4. Make SQL Command as short as possible.

        Example:
        1.  Prompt: 我想搜尋所有的個人資料
            Answer: SELECT * FROM ...
        
        Check the format must be like SELECT ... FROM ... WHERE ...;, DOUBLE CHECK the notices and examples.
        ''')

    def search_from_sql(sqlCommand: str) -> str:
        # 加入 API， return 查詢結果
        print(sqlCommand)
        return SummaryFunc.store_dataset(getCsvDataset.dataset_query_sql("./database/SQL", llm, sqlCommand))
        # return "OK"

    searchFromSQL = StructuredTool.from_function(
        func=search_from_sql,
        name="search from MSSQL",
        description=f'''Search for the desired data from MSSQL using SQL command and returns the search results. May need use Join, focus on description,
                        Table list: {get_tables_name("./database/SQL")}
                        ''',
        args_schema=SearchSQLInput,
        return_direct=True,
        # coroutine= ... <- you can specify an async method if desired as well
    )

    class SummarySchema(BaseModel):
        input: str = Field(description='''
                input as same as user input.
        ''')

    def summaryDataset() -> str:
        # return SummaryFunc.get_dataset()
        return SummaryFunc.summary(llm)

    summaryFromData = StructuredTool.from_function(
        func=summaryDataset,
        name="dataset summary",
        description="This tool is uesd to summarize the datasets. If input doesn't mention the words like 'summary', don't use this tool. ",
        return_direct=True,
        # coroutine= ... <- you can specify an async method if desired as well
    )

    # === All Tools ===
    tools = [calculator, getWordLength, searchFromFile, searchFromNews] # summaryFromData  


    # === Memory ===
    # from langchain.memory import ConversationBufferWindowMemory
    # from langchain.agents import load_tools

    # memory = ConversationBufferWindowMemory(
    #     memory_key="chat_history", k=2, return_messages=True, output_key="output"
    # )# , output_key="output"


    # === Prompt Template ===
    system = '''Respond to the human as helpfully and accurately as possible. You have access to the following tools:

    {tools}

    Use a json blob to specify a tool by providing an action key (tool name) and an action_input key (tool input).

    Valid "action" values: "Final Answer" or {tool_names}

    Provide only ONE action per $JSON_BLOB, as shown:
    Action (Json format):
    ```
    {{
    "action": $TOOL_NAME,
    "action_input": $INPUT
    }}
    ```

    Follow this format:

    Question: input question to answer
    Thought: consider what input do action required, must follow the description that action provided
    Action (Json format):
    ```
    $JSON_BLOB
    ```
    Observation: action result
    ... (repeat Thought/Action/Observation 3 times)
    Thought: I know what to respond, and I have to respond in traditional chinese
    Action (Json format):
    ```
    {{
    "action": "Final Answer",
    "action_input": "Final response in traditional chinese"
    }}
    ```

    Begin! 
    Reminder to ALWAYS respond with a valid json blob of a single action. 
    Use tools if necessary. Respond directly if appropriate. 
    Format is Action: ```$JSON_BLOB```then Observation
    '''

    human = '''{input}

    {agent_scratchpad}

    (reminder to respond in a JSON blob without annotations no matter what)'''

    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", system),
            # MessagesPlaceholder("chat_history", optional=True),
            ("human", human),
        ]
    )

    # === Agent ===
    my_agent = create_structured_chat_agent(llm, tools, prompt)
    # === Agent Executor ===
    return AgentExecutor(agent = my_agent, verbose=True, tools = tools, max_iterations=3) #, handle_parsing_errors=True

Agent_Executor = reload()

if __name__ == "__main__":

    import time

    while True:
        data = input("Message: ")
        if 'Exit' == data:
            break

        start = time.time()
        print(Agent_Executor.invoke({"input": data}))
        end = time.time()

        print(f"\nTotal time: {end - start}")
        print("\n\n")