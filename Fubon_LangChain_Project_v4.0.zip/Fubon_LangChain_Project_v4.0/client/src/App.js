import React, { useEffect, useState } from 'react';
import axios from 'axios';

import './App.css';
import human_pic from './assets/human.jpg';
import ai_pic from './assets/ai.jpg';

import { ArrowSVG, DotsSVG, HistorySVG, NewChatSVG } from './SVG';

import {NavBarContext, TableContext, HistoryContext} from './Context';

import { NavBarLeft, NavBarTop } from './NavBar';
import { MutableFS } from './MutableFS';
import HtmlRenderer from './Table';

import History from './History';
import ConnectSettingPage from './ConnectSettingPage';
import CommonSettingPage from './CommonSettingPage';

// Scroll bar 聊天內容增加就自動向下
// 新增聊天以及歷史紀錄

  

function App() {
	const [userInput, setUserInput] = useState('');
	const [messages, setMessages] = useState([
		{
			AiResponse: "您好，請問您要查詢什麼資料呢？",
			AiTime: "",
		}
	]);
	const [loading, setLoading] = useState(false);

	const [showTab, setTab] = useState([true, false]);
	
	const [analysis, setAnalysis] = useState(false);
	const [check, setCheck] = useState(false);

	const [id, setID] = useState(5);

	const [chatId, setChatId] = useState(-1);

	const [menuShow, setMenuShow] = useState(false);
	const [historyShow, setHistoryShow] = useState(false);

	const saveHistory = (history) => {

		axios.post('http://localhost:5001/save_history', {
			'chatId': chatId,
			'chat': history,
		})
		.then(function (response){
			setChatId(response.data.chatId);
		})
		.catch(function (err){
			console.log(err);
		})
	}

	const handleInputChange = (e) => {
			setUserInput(e.target.value);

			if(e.target.scrollHeight < 76){
				e.target.style.overflowY = "hidden";
				e.target.style.height = "auto";
				e.target.style.height = (e.target.scrollHeight) + "px";
			}
			else{
				e.target.style.height = "76px";
				e.target.style.overflowY = "auto";
			}
		};


	const handleSendMessage = async (e) => {
		e.preventDefault();
		let api = '';
		let waiting = "";

		document.getElementById('content').style.height = "auto";

		if(analysis){
			console.log("analysis");
			setAnalysis(true);
			api = 'http://localhost:5001/get_summary_test';
			waiting = "請等待總結";
		}
		else if(check){
			api = 'http://localhost:5001/get_query';
			// api ='http://localhost:5001/get_test';
			waiting = "請等待資料查詢";
		}
		else{
			api ='http://localhost:5001/get_keyword';
			// api ='http://localhost:5001/get_keyword_test';
			waiting = "請等待回覆";
		}
		if(userInput !== ''){
			setLoading(true);
			setUserInput('');
			let userInputTime = new Date();

			const loadingMessage = {
				HumanInput: userInput,
				AiResponse: waiting,
				HumanTime: userInputTime.toLocaleString(),
				AiTime: "",
			};
			// console.log('this loadingMessage:', loadingMessage);

			setMessages((prevMessages) => [...prevMessages, loadingMessage]);

			axios.post(api, {
				inputText : userInput
			})
			.then(function (response){
				//console.log('status:', response.status)
				var status = response.status;
				const resp = status === 200 ? response.data.response : '暫時無法解析您的問題';
				
				if(response.data.check === 'True'){
					setCheck(true);
				}
				else{
					setCheck(false);
				}

				let AiResponseTime = new Date();

				// if (!resp.includes("無法查詢") && resp.includes("SELECT")){
				// 	window.open('/table', "表格資料", 'height=80%').focus();
				// }

				const newMessage = {
					HumanInput: userInput,
					AiResponse: resp,
					HumanTime: userInputTime.toLocaleString(),
					AiTime: AiResponseTime.toLocaleString(),
				};
				// console.log('this newMessage:', newMessage);
				setMessages((prevMessages) => [...prevMessages.slice(0, -1), newMessage]);
				if(id === 5){
					setID(6);
				}
				else{
					setID(5);
				}
				saveHistory([...messages, newMessage]);
			})
			.catch(function (err){
				alert(`${err}`);
				setLoading(false);
				let AiResponseTime = new Date();

				const newMessage = {
					HumanInput: userInput,
					AiResponse: "請重新嘗試",
					HumanTime: userInputTime.toLocaleString(),
					AiTime: AiResponseTime.toLocaleString(),
				};
				setMessages((prevMessages) => [...prevMessages.slice(0, -1), newMessage]);
				saveHistory([...messages, newMessage])
			})
			.finally(() => {
				setLoading(false);
			});
		};
	};

	useEffect(()=>{
		document.getElementsByClassName('chat')[0].scrollTop = document.getElementsByClassName('chat')[0].scrollHeight;
	}, [messages])


	return (
		<>	
			<div className='bg-container'>
				<NavBarTop/>
				<div className='bottom-container'>
					<NavBarContext.Provider value={{
						tab_setter: setTab,
					}}>
						<NavBarLeft/>
					</NavBarContext.Provider>

					{showTab[0] && 
					<>
						<TableContext.Provider value={{
							id_state: id,
							id_setter: setID
						}}>
							<HtmlRenderer/>
						</TableContext.Provider>
						<div className="chatbox">
							<div className='menu-btn' role='button' onClick={()=>{setMenuShow(!menuShow)}}>
								<DotsSVG />	
								{menuShow &&
									<div className='menu-list'>
										<div className='menu-func-btn' role='button' onClick={() => {setChatId(-1); setMessages([{AiResponse: "您好，請問您要查詢什麼資料呢？", AiTime: "",}]); setCheck(false);}}>
											<NewChatSVG /> <span>新增聊天</span>
										</div>
										<div className='menu-func-btn' role='button' onClick={() => {setHistoryShow(true);}}>
											<HistorySVG /> <span>聊天歷史紀錄</span>
										</div>
									</div>}
							</div> 
							{historyShow &&
								<HistoryContext.Provider value={{
												message_state: messages,
												message_setter: setMessages,
												chatId_setter: setChatId,
												check_setter: setCheck,
												show_state: historyShow,
												show_setter: setHistoryShow,
											}}>
									<History />
								</HistoryContext.Provider>
							}
							<div className="chat scrollbar">
								<div className="chat-title">
									聊天室
								</div>
								<div>
									{messages.map((message, index) => (
									<div key={index}>
										{message.HumanInput && 
											<>
											<div className="humanTime">{message.HumanTime}</div>
											<div className="dialog human">
												<div style={{ whiteSpace: 'pre-wrap' }} className="human-box">
													{message.HumanInput}
												</div>
												<img alt="" className="img-profile" 
													src={human_pic} 
												/>
											</div>
											</>
										}
										<div className="AiTime">{message.AiTime}</div>
										<div className="dialog ai">
											<img alt="" className="img-profile" 
												src={ai_pic} 
											/>
											<div style={{ whiteSpace: 'pre-wrap' }} className="ai-box">
												<span>{message.AiResponse}</span>{loading && (message.AiResponse.includes("請等待")) && <span className="dot"></span>}
											</div>
										</div>
									</div>))}
								</div>
							</div>
							<form 
								className="inputbox" 
								onSubmit={handleSendMessage}
							>	
								<textarea
										className="msgbox"
										id="content"
										placeholder="Message"
										type="text"
										value={userInput}
										onChange={handleInputChange}

										rows={"1"}
								/>
								<button
									className= 'btn-send'
									type="submit"
									disabled = {loading}
								>
									<span>Send</span>
									<ArrowSVG/>
								</button>
							</form>
						</div>
					</>}
					{showTab[1] && <MutableFS/>}
					{showTab[2] && <CommonSettingPage/>}
					{showTab[3] && <ConnectSettingPage/>}
				</div>
			</div>
		</>
	);
}

export default App;