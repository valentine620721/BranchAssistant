import { useState } from 'react';
import axios from 'axios';

import './QueryPage.css'

function QueryPage() {

    const [result, setResult] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault(); // 防止表单的默认提交行为

        // 获取表单数据
        const formData = new FormData(e.target);
        const data = {};
        formData.forEach((value, key) => {
            data[key] = value;
        });

        // console.log(data);

        axios.post('http://127.0.0.1:5001/get_direct_query', data)
            .then(response => {
                // 处理成功响应
                console.log('成功:', response.data);
                setResult(response.data.result)
            })
            .catch(error => {
                // 处理错误响应
                console.error('錯誤:', error);
                setResult("錯誤回應");
            });
    };

  
    return (
        <>
            <div className='query-box-c'>
                <div className='query-box-d'>
                    <form onSubmit={handleSubmit}>

                        <label for="username">帳號:</label>
                        <input type="text" id="username" name="username" required />
                        <br/>
                        <br/>

                        <label for="password">密碼:</label>
                        <input type="password" id="password" name="password" required />
                        <br/>
                        <br/>

                        <label htmlFor="options">選擇資料庫:</label>
                        <select id="options" name="database">
                            <option value="Oracle">Oracle</option>
                            <option value="MSSQL">MSSQL</option>
                        </select>
                        <br/>

                        <label htmlFor="sql-query">自定義SQL查詢:</label>
                        <br/>
                        <textarea id="sql-query" name="sql-query" rows="4" cols="50" placeholder="請輸入您的 SQL 查詢語句"></textarea>

                        <button type="submit" style={{display: 'block'}}>提交</button>
                        <br/>
                        <br/>
                        <label>{result}</label>
                    </form>
                </div>
            </div>
        </>
    );
}

export default QueryPage;